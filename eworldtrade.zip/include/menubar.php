<div class="row menu-bar">
    <div class="col-md-7">
        <nav class="navbar-expand-md main-menu ">
            <ul class="menu">
                <div class="dropdown">
                    <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bars"></i>
                        Categories</a>
                    </button>
                    <ul class="dropdown-menu">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle dropdown-item" href="<?php  echo $siteurl?>" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Apparel
                                <i class="fas fa-angle-right"></i>
                            </a>
                            <div class="dropdown-menu drop2" aria-labelledby="navbarDropdownMenuLink">
                                <div class="row submenu-row">
                                    <div class="col-md-6">
                                        <h5>
                                            <a href="" class="text-danger text-truncate">Underwear</a></h5>
                                        <ul>
                                            <li><a href="" class="dropdown-item text-truncate">Bra</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Womens Panties</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Mens Briefs Boxers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Shapers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Sexy Underwear</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Bra Brief Sets</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Garters Bel</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Camisoles 7983</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><a href="" title="Wedding Apparel Accessories" class="text-danger text-truncate">Wedding Apparel Accessories</a></h5>
                                        <ul>
                                            <li><a href="" class="dropdown-item text-truncate">Wedding Dresses</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Bridal Accessories</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Bridal Gown</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle dropdown-item" href="<?php  echo $siteurl?>" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Home Appliances
                                <i class="fas fa-angle-right"></i>
                            </a>
                            <div class="dropdown-menu drop2" aria-labelledby="navbarDropdownMenuLink">
                                <div class="row submenu-row">
                                    <div class="col-md-6">
                                        <h5>
                                            <a href="" class="text-danger text-truncate">Cooking Appliances</a></h5>
                                        <ul>
                                            <li><a href="" class="dropdown-item text-truncate">Cooktops</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Induction Cookers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Ovens</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Range Hoods</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Rice Cookers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Electric Deep Fryers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Hot Plates</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Electric Grills Electric Griddles</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><a href="" title="Wedding Apparel Accessories" class="text-danger text-truncate">Air Conditioning Appliances</a></h5>
                                        <ul>
                                            <li><a href="" class="dropdown-item text-truncate">DVD Burner</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Fans</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Humidifiers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Air Purifiers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Air Conditioners</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Dehumidifiers</a></li>
                                            <li><a href="" class="dropdown-item text-truncate">Other Air Conditioning Appliances</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li><a class="dropdown-item" href="#">Home Appliances <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Machinery <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Beauty & Personal Care <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Security & Protection <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Lights & Lighting <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Automobiles  & Motorcycles <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Chemicals <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Food & Beverage <i class="fas fa-angle-right"></i></a></li>
                        <li><a class="dropdown-item" href="#">Minerals & Metallurgy <i class="fas fa-angle-right"></i></a></li>
                        <li class="li-btndrop"><a class="dropdown-item btn-drop" href="#">View All Categories</a></li>
                    </ul>
                </div>


                <li>
                    <a href="javascript:">

                </li>
                <li>
                    <a href="javascript:">Buyers</a>
                </li>
                <li>
                    <a href="javascript:">Products</a>
                </li>
                <li>
                    <a href="javascript:">Companies</a>
                </li>
                <li>
                    <a href="javascript:">Manufacturers</a>
                </li>
            </ul>
        </nav>
    </div>
    <div class="col-md-5">
        <div class="btn-block">
            <a href="javascript:" class="btn btn-red various" data-fancybox="" data-src="#popupform">
                <img src="<?php echo $siteurl ?>/assets/images/prem-ico.png" alt="">Premium Services
            </a>
            <a href="javascript:"><img src="<?php echo $siteurl ?>/assets/images/contact-icon.png" alt="">Contact Us</a>
        </div>
    </div>
</div>