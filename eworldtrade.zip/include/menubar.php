<div class="row menu-bar">
    <div class="col-md-7">
        <ul class="menu">
            <div class="dropdown">
                <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-bars"></i>
                    Categories</a>
                </button>
                <ul class="dropdown-menu">
                    <li>
                        <a class="dropdown-item" href="#">
                            Apparel <i class="fas fa-angle-right"></i>
                        </a>
                        <div class="submenu-row">
                            <div class="col-md-6">
                                <h5>
                                    <a href="" class="text-danger text-truncate">Underwear</a></h5>
                                <ul>
                                    <li><a href="" class="text-truncate">Bra</a></li>
                                    <li><a href="" class="text-truncate">Womens Panties</a></li>
                                    <li><a href="" class="text-truncate">Mens Briefs Boxers</a></li>
                                    <li><a href="" class="text-truncate">Shapers</a></li>
                                    <li><a href="" class="text-truncate">Sexy Underwear</a></li>
                                    <li><a href="" class="text-truncate">Bra Brief Sets</a></li>
                                    <li><a href="" class="text-truncate">Garters Bel</a></li>
                                    <li><a href="" class="text-truncate">Camisoles 7983</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h5><a href="" title="Wedding Apparel Accessories" class="text-danger text-truncate">Wedding Apparel Accessories</a></h5>
                                <ul>
                                    <li><a class="text-truncate">Wedding Dresses</a></li>
                                    <li><a class="text-truncate">Bridal Accessories</a></li>
                                    <li><a class="text-truncate">Bridal Gown</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li><a class="dropdown-item" href="#">Home Appliances <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Machinery <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Beauty & Personal Care <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Security & Protection <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Lights & Lighting <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Automobiles  & Motorcycles <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Chemicals <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Food & Beverage <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">Minerals & Metallurgy <i class="fas fa-angle-right"></i></a></li>
                    <li><a class="dropdown-item" href="#">View All Categories</a></li>
                </ul>
            </div>


            <li>
                <a href="javascript:">

            </li>
            <li>
                <a href="javascript:">Buyers</a>
            </li>
            <li>
                <a href="javascript:">Products</a>
            </li>
            <li>
                <a href="javascript:">Companies</a>
            </li>
            <li>
                <a href="javascript:">Manufacturers</a>
            </li>
        </ul>
    </div>
    <div class="col-md-5">
        <div class="btn-block">
            <a href="javascript:" class="btn btn-red various" data-fancybox="" data-src="#popupform">
                <img src="<?php echo $siteurl ?>/assets/images/prem-ico.png" alt="">Premium Services
            </a>
            <a href="javascript:"><img src="<?php echo $siteurl ?>/assets/images/contact-icon.png" alt="">Contact Us</a>
        </div>
    </div>
</div>