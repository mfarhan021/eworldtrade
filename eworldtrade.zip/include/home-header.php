<?php include($_SERVER['DOCUMENT_ROOT']."/eworldtrade/include/header-topbar.php"); ?>
<header>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo $siteurl ?>" class="logo">
                    <img src="<?php echo $siteurl ?>/assets/images/logo.svg" alt="">
                </a>
            </div>
            <div class="col-md-6">
                <?php include($_SERVER['DOCUMENT_ROOT']."/eworldtrade/include/header-post.php"); ?>
            </div>
        </div>
        <?php include($_SERVER['DOCUMENT_ROOT']."/eworldtrade/include/menubar.php"); ?>
    </div>
</header>