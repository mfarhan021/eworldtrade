<section class="topbar">
    <div class="container">
        <p>
            <span>Join Today</span> and Be a Part of The Fastest Growing B2B Network
        </p>
        <a href="javascript:" class="btn btn-red various" data-fancybox="" data-src="#popupform">Join Now</a>
    </div>
</section>
