<ul class="post">
    <li>
        <p>
            <img src="<?php echo $siteurl ?>/assets/images/en-flag.png" alt="">
            English-PK
        </p>
    </li>
    <li>
        <i class="fas fa-user"></i>
        <a href="#">Sign Up</a> / <a href="#">Sign in</a>
    </li>
    <li>
        <a href="javascript:" class="btn btn-red various" data-fancybox="" data-src="#popupform">Post RFQ</a>
    </li>
</ul>