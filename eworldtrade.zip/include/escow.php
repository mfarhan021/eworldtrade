<div class="escow-img">
    <div class="container">
        <img src="<?php echo $siteurl ?>/assets/images/escrow2.png" alt="">
    </div>
</div>