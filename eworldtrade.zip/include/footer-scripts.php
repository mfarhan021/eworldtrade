<script type="text/javascript" src="<?php echo $siteurl; ?>assets/js/libs.js"></script>
<script type="text/javascript" src="<?php echo $siteurl; ?>assets/js/functions.js"></script>